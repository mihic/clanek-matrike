import matplotlib.pyplot as plt

def izrisiGraf(sloRez):
    sezLegende = list()
    sezImen = list()
    for alg1 in sloRez:
        (n,cas)=sloRez[alg1]
        x=plt.plot(n, cas, label=alg1)

    ##plt.plot([0],[0])
    plt.legend()
    plt.show()

##izrisiGraf({"bf":([1, 2, 3, 4], [2, 3, 10, 17]),
##            "ms3":([1, 2, 3, 4], [4, 5, 7, 10])})

def legendaAlgoritmi(fileRez="rez.txt"):
    sloRez = dict()
    sezN = list()
    sezCas = list()
    skok = False
    with open(fileRez,"r") as f:
        for vrstica in f:
            sez = vrstica.split(";")
            if skok:
                skok = False
                continue
            elif len(sez)<3:
                if len(sezN)>0:
                    sloRez[znacka] = (sezN,sezCas)
                    sezN = list()
                    sezCas = list()
                elif len(sez[0])>1:
                    znacka = sez[0]
                    skok = True
            else:
                sezN.append(float(sez[0]))
                sezCas.append(float(sez[4]))

        sloRez[znacka] = (sezN,sezCas)

    return sloRez

def oklestiSlovar(slo,kljuci):
    novSlo = dict()
    for kljuc in kljuci:
        if kljuc in slo:
            novSlo[kljuc] = slo[kljuc]

    return novSlo

if __name__ == "__main__":
    sloRez = legendaAlgoritmi(fileRez="rez.txt")
    izrisiGraf(sloRez)

##    sloRez2 = oklestiSlovar(sloRez,["transponirano_mnozenje","BLAS1024","BLAS4048"])
##    izrisiGraf(sloRez2)

##    sloRez1 = oklestiSlovar(sloRez,["klasicno_mnozenje","transponirano_mnozenje","rekurzivno_transponirano",
##                                    "rekurzivno_mnozenje", "podkubicen_algoritem","podkubicen_en_korak"])
##    izrisiGraf(sloRez1)

##    sloRez1 = oklestiSlovar(sloRez,["klasicno_mnozenje","transponirano_mnozenje","rekurzivno_transponirano","rekurzivno_mnozenje"])
##    izrisiGraf(sloRez1)

    
##    sloRez1 = oklestiSlovar(sloRez,["klasicno_mnozenje","transponirano_mnozenje"])
##    izrisiGraf(sloRez1)
    
##    sloRez2 = oklestiSlovar(sloRez,["BLAS4", "BLAS16", "BLAS64","BLAS256","BLAS1024","BLAS4048"])
##    izrisiGraf(sloRez2)

    sloRez2 = oklestiSlovar(sloRez,["BLAS16", "BLAS64", "podkubicen_algoritem","podkubicen_en_korak","rekurzivno_transponirano","transponirano_mnozenje"])
    izrisiGraf(sloRez2)

