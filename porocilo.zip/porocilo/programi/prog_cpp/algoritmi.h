#ifndef ALGORITMI_H
#define ALGORITMI_H

typedef std::vector<std::vector<double>> Tmat;

Tmat klasicno_mnozenje(Tmat &, Tmat &);
Tmat transponirano_mnozenje(Tmat &, Tmat &);
Tmat rekurzivno_mnozenje(Tmat &, Tmat &);
Tmat rekurzivno_transponirano_mnozenje(Tmat &, Tmat &);
Tmat podkubicen_enkrat(Tmat &, Tmat &);
Tmat podkubicen(Tmat &, Tmat &);

#endif
