def transponiraj(mat):
    return [[mat[i][j] for i in range(len(mat))] for j in range(len(mat[0]))]

def vektorsko(v1,v2):
    a = len(v1)
    v3 = [0 for _ in range(a)]
    ##print(v1)
    ##print(v2)
    for i in range(a):
        v3[i] = v1[i] * v2[i]

    return sum(v3)

def mnozenje2(mat1,mat2):
    a = len(mat1)
    mat2 = transponiraj(mat2)
    b = len(mat2)
    mat = [[0 for _ in range(b)] for  _ in range(a)]
    ##print(mat2)
    for i in range(a):
        for j in range(b):
            mat[i][j] = vektorsko(mat1[i], mat2[j])

    return mat

def mnozenje1(mat1,mat2):
    a = len(mat1)
    b = len(mat2[0])
    c = len(mat1[0])
    if c != len(mat2):
        print("Dimenziji se ne ujemata")
        return

    mat = [[0 for _ in range(b)] for  _ in range(a)]

    for i in range(a):
        for j in range(b):
            s = 0
            for k in range(c):
                s += mat1[i][k]*mat2[k][j]

            mat[i][j] = s

    return mat

mat1 = [[1,2,3],
        [4,5,6]]

mat2 = [[1,2],
        [4,5],
        [10,100]]

import random
import time

def test():
    n = 500
    print("n =",n)
    mat1 = [[random.random() for _ in range(n)] for _ in range(n)]
    mat2 = [[random.random() for _ in range(n)] for _ in range(n)]

    print("prvi")
    start = time.time()
    mnozenje1(mat1,mat2)
    end = time.time()
    print(end - start)

    print("drugi")
    start = time.time()
    mnozenje2(mat1,mat2)
    end = time.time()
    print(end - start)
