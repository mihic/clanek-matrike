def dobro_sestevanje(sez):
    sez.sort(key=lambda x: abs(x))
    return sum(sez)

def boljse_sestevanje(sez):
    sez.sort(key=lambda x: abs(x))
    
    ##optimalno in zelo pocasno
    ##meja = (abs(sez[0])+abs(sez[1]))

    while len(sez)>2:
        ##hitro in kvalitetno
        meja = 2*(abs(sez[0])+abs(sez[1])+abs(sez[2]))
        novSez = [0]
        for i in range(len(sez)):
            if (abs(novSez[-1])< meja):
                novSez[-1] += sez[i]
            else:
                novSez.append(sez[i])

        novSez.sort(key=lambda x: abs(x))
        ##print(len(sez))
        sez = novSez     

    return sum(sez)

def testiraj_sestevanja():
    sez = [1/i for i in range(1,4000001)]
    ##sez = [((-1)**i)*(1/i) for i in range(1,4000001)]
    print("Res obstajajo enostavne izboljsave:")
    print("Slabse je (padajoce urejen):")
    print(sum(sez))
    print("Bolje je (narascujoce urejen):")
    print(sum(reversed(sez)))
    print("Se bolj natancno z algoritmom:")
    print(boljse_sestevanje(sez))

testiraj_sestevanja()
