//#include <iostream>
//#include <iomanip>
#include <vector>
#include <functional>
#include <algorithm>
#include "algoritmi.h"

typedef std::vector<std::vector<double>> Tmat;

/*
void prikaz2(Tmat &mat){
    for (auto &vrstica : mat){
        std::cout << "|";
        for (auto &element : vrstica){
            std::cout << std::setw(6) << element;
        }
        std::cout << "|" << std::endl;
    }
    std::cout << std::endl;
}
*/
Tmat klasicno_mnozenje(Tmat &mat1, Tmat &mat2){
    int a = mat1.size();
    int b = mat1[0].size();
    int c = mat2[0].size();

    std::vector<double> nicelni(c, 0.0);
    Tmat mat3(a, nicelni);
    for (int i = 0; i<a; i+=1){
        for (int j = 0; j<c; j+=1){
            double s = 0;
            for (int k = 0; k<b; k+=1){
                    s+=mat1[i][k]*mat2[k][j];
            }
            mat3[i][j] = s;
        }
    }
    return mat3;
}

Tmat transponiraj(Tmat &mat){
    int a = mat.size();
    int b = mat[0].size();
    
    std::vector<double> nicelni1(a, 0.0);
    Tmat mat3(b, nicelni1);
    for (int i = 0; i<a; i+=1){
        for (int j = 0; j<b; j+=1){
            mat3[j][i] = mat[i][j];
        }   
    }
    return mat3;
}

Tmat gl_transponirano_mno(Tmat &mat1, Tmat &mat4){
    int a = mat1.size();
    int b = mat1[0].size();
    int c = mat4.size();
    
    std::vector<double> nicelni(c, 0.0);
    Tmat mat3(a, nicelni);
    for (int i = 0; i<a; i+=1){
        for (int j = 0; j<c; j+=1){
            double s = 0;
            for (int k = 0; k<b; k+=1){
                    s+=mat1[i][k]*mat4[j][k];
            }
            mat3[i][j] = s;
        }
    }
    return mat3;
}

Tmat transponirano_mnozenje(Tmat &mat1, Tmat &mat2){   
    Tmat mat4 = transponiraj(mat2);
    return gl_transponirano_mno(mat1, mat4);
}

void pomozna_mno_kla(Tmat &mat1, Tmat &mat2, Tmat &mat3,
                     int a1, int a2, 
                     int b1, int b2,
                     int c1, int c2){

    for (int i = a1; i<a2; i+=1){
        for (int j = c1; j<c2; j+=1){
            double s = 0;
            for (int k = b1; k<b2; k+=1){
                    s+=mat1[i][k]*mat2[k][j];
            }
            mat3[i][j] += s;
        }
    }
}

void rek_mno_pomozna(Tmat &mat1, Tmat &mat2, Tmat &mat3,
                     int a1, int a2, 
                     int b1, int b2,
                     int c1, int c2){
    
    int aD = a2-a1;
    int bD = b2-b1;
    int cD = c2-c1;
    int aP = a1+aD/2;
    int bP = b1+bD/2;
    int cP = c1+cD/2;
    int minDabc = std::min({aD, bD, cD});
    //std::cout << aD << "|" << bD << "|" << cD << std::endl;
    
    if(minDabc<100){
        pomozna_mno_kla(mat1, mat2, mat3, a1, a2,  b1, b2, c1, c2);
    }
    else{
        rek_mno_pomozna(mat1, mat2, mat3, a1, aP,  b1, bP, c1, cP);
        rek_mno_pomozna(mat1, mat2, mat3, a1, aP,  b1, bP, cP, c2);
        rek_mno_pomozna(mat1, mat2, mat3, a1, aP,  bP, b2, c1, cP);
        rek_mno_pomozna(mat1, mat2, mat3, a1, aP,  bP, b2, cP, c2);
        
        rek_mno_pomozna(mat1, mat2, mat3, aP, a2,  b1, bP, c1, cP);
        rek_mno_pomozna(mat1, mat2, mat3, aP, a2,  b1, bP, cP, c2);
        rek_mno_pomozna(mat1, mat2, mat3, aP, a2,  bP, b2, c1, cP);
        rek_mno_pomozna(mat1, mat2, mat3, aP, a2,  bP, b2, cP, c2);
    }
}

Tmat rekurzivno_mnozenje(Tmat &mat1, Tmat &mat2){
    int a = mat1.size();
    int b = mat1[0].size();
    int c = mat2[0].size();
    int a1 = 0; 
    int b1 = 0;
    int c1 = 0;
    
    std::vector<double> nicelni(c, 0.0);
    Tmat mat3(a, nicelni);
    rek_mno_pomozna(mat1, mat2, mat3, a1, a,  b1, b, c1, c);
    
    return mat3;
}


void rek_tra_mno_zakljucek(Tmat &mat1, Tmat &mat2, Tmat &mat3,
                     int a1, int a2, 
                     int b1, int b2,
                     int c1, int c2){

    //mat2 je ze transponirana
    for (int i = a1; i<a2; i+=1){
        for (int j = c1; j<c2; j+=1){
            double s = 0;
            for (int k = b1; k<b2; k+=1){
                    //std::cout << "ijk|" << i << "|" << j << "|" << k << std::endl;
                    s+=mat1[i][k]*mat2[j][k];
            }
            mat3[i][j] += s;
        }
    }
}

void rek_tra_mno_pomozna(Tmat &mat1, Tmat &mat4, Tmat &mat3,
                         int a1, int a2, 
                         int b1, int b2,
                         int c1, int c2){
    
    int aD = a2-a1;
    int bD = b2-b1;
    int cD = c2-c1;
    int aP = a1+aD/2;
    int bP = b1+bD/2;
    int cP = c1+cD/2;
    int minDabc = std::min({aD, bD, cD});
    
    if(minDabc<100){
        rek_tra_mno_zakljucek(mat1, mat4, mat3, a1, a2,  b1, b2, c1, c2);
    }
    else{
        rek_tra_mno_pomozna(mat1, mat4, mat3, a1, aP,  b1, bP, c1, cP);
        rek_tra_mno_pomozna(mat1, mat4, mat3, a1, aP,  b1, bP, cP, c2);
        rek_tra_mno_pomozna(mat1, mat4, mat3, a1, aP,  bP, b2, c1, cP);
        rek_tra_mno_pomozna(mat1, mat4, mat3, a1, aP,  bP, b2, cP, c2);
        
        rek_tra_mno_pomozna(mat1, mat4, mat3, aP, a2,  b1, bP, c1, cP);
        rek_tra_mno_pomozna(mat1, mat4, mat3, aP, a2,  b1, bP, cP, c2);
        rek_tra_mno_pomozna(mat1, mat4, mat3, aP, a2,  bP, b2, c1, cP);
        rek_tra_mno_pomozna(mat1, mat4, mat3, aP, a2,  bP, b2, cP, c2);
    }
}

Tmat gl_rekurzivno_transponirano_mno(Tmat &mat1, Tmat &mat4){
    int a = mat1.size();
    int b = mat1[0].size();
    int c = mat4.size();
    int a1 = 0; 
    int b1 = 0;
    int c1 = 0;

    std::vector<double> nicelni(c, 0.0);
    Tmat mat3(a, nicelni);
    rek_tra_mno_pomozna(mat1, mat4, mat3, a1, a,  b1, b, c1, c);
    
    return mat3;
}

Tmat rekurzivno_transponirano_mnozenje(Tmat &mat1, Tmat &mat2){
    Tmat mat4 = transponiraj(mat2);
    return gl_rekurzivno_transponirano_mno(mat1, mat4);
}

Tmat vrni_obmocje_matrike(Tmat &mat1,
                          int x1, int x1max,
                          int x2, int x2max){
                        
    int x1D = x1max - x1;
    int x2D = x2max - x2;
    
    std::vector<double> nicelni(x2D, 0.0);
    Tmat mat3(x1D, nicelni);
    for (int i = 0; i<x1D; i+=1){
        for (int j = 0; j<x2D; j+=1){
            mat3[i][j] += mat1[x1+i][x2+j];
        }
    }
    
    return mat3;
}

void pristej_rezultatu(Tmat &mat1, Tmat &mat3,
                       int x1, int x1max,
                       int x2, int x2max){
                        
    int x1D = x1max - x1;
    int x2D = x2max - x2;
    
    for (int i = 0; i<x1D; i+=1){
        for (int j = 0; j<x2D; j+=1){
            mat3[x1+i][x2+j] += mat1[i][j];
        }
    }
}

void odstej_rezultatu(Tmat &mat1, Tmat &mat3,
                      int x1, int x1max,
                      int x2, int x2max){
                        
    int x1D = x1max - x1;
    int x2D = x2max - x2;
    
    for (int i = 0; i<x1D; i+=1){
        for (int j = 0; j<x2D; j+=1){
            mat3[x1+i][x2+j] += -mat1[i][j];
        }
    }
}

Tmat pomozno_sestevanje(Tmat &mat1, Tmat &mat2,
                        int x1, int x1max,
                        int x2, int x2max, 
                        int y1, int y1max,
                        int y2, int y2max){
                        
    int x1D = x1max - x1;
    int x2D = x2max - x2;
    int y1D = y1max - y1;
    int y2D = y2max - y2;
    
    int iMax = std::max({x1D, y1D});
    int jMax = std::max({x2D, y2D});
    
    std::vector<double> nicelni(jMax, 0.0);
    Tmat mat3(iMax, nicelni);
    
    for (int i = 0; i<x1D; i+=1){
        for (int j = 0; j<x2D; j+=1){
            mat3[i][j] += mat1[x1+i][x2+j];
        }
    }
    
    for (int i = 0; i<y1D; i+=1){
        for (int j = 0; j<y2D; j+=1){
            mat3[i][j] += mat2[y1+i][y2+j];
        }
    }
    
    return mat3;
}

Tmat pomozno_odstevanje(Tmat &mat1, Tmat &mat2,
                        int x1, int x1max,
                        int x2, int x2max, 
                        int y1, int y1max,
                        int y2, int y2max){
                        
    int x1D = x1max - x1;
    int x2D = x2max - x2;
    int y1D = y1max - y1;
    int y2D = y2max - y2;
    
    int iMax = std::max({x1D, y1D});
    int jMax = std::max({x2D, y2D});
    
    std::vector<double> nicelni(jMax, 0.0);
    Tmat mat3(iMax, nicelni);
    
    for (int i = 0; i<x1D; i+=1){
        for (int j = 0; j<x2D; j+=1){
            mat3[i][j] += mat1[x1+i][x2+j];
        }
    }
    
    for (int i = 0; i<y1D; i+=1){
        for (int j = 0; j<y2D; j+=1){
            mat3[i][j] += -mat2[y1+i][y2+j];
        }
    }
    
    return mat3;
}

void podkubicen_pomozna(Tmat &mat1, Tmat &mat4, Tmat &mat3,
                        int a1, int a2, 
                        int b1, int b2,
                        int c1, int c2){
    

    int aD = a2-a1;
    int bD = b2-b1;
    int cD = c2-c1;
    int aP = a1+aD/2;
    int bP = b1+bD/2;
    int cP = c1+cD/2;
    int minDabc = std::min({aD, bD, cD});
    
    if(minDabc<400){
        rek_tra_mno_pomozna(mat1, mat4, mat3, a1, a2,  b1, b2, c1, c2);
    }
    else{
        Tmat matA1B1 = pomozno_sestevanje(mat1, mat1, 
                                          //A1
                                          a1, aP, 
                                          b1, bP, 
                                          //B1
                                          aP, a2, 
                                          b1, bP);
                                          
        Tmat matX1Y1 = pomozno_sestevanje(mat4, mat4, 
                                          //X1
                                          c1, cP, 
                                          b1, bP, 
                                          //Y1
                                          cP, c2, 
                                          b1, bP);
        
        Tmat matA2B2 = pomozno_sestevanje(mat1, mat1, 
                                          //A2
                                          a1, aP, 
                                          bP, b2, 
                                          //B2
                                          aP, a2, 
                                          bP, b2);
        
        Tmat matX2Y2 = pomozno_sestevanje(mat4, mat4, 
                                          //X2
                                          c1, cP, 
                                          bP, b2, 
                                          //Y2
                                          cP, c2, 
                                          bP, b2);
        
        
        Tmat matA1mB2 = pomozno_odstevanje(mat1, mat1, 
                                          //A1
                                          a1, aP, 
                                          b1, bP, 
                                          //B2
                                          aP, a2, 
                                          bP, b2);
        
        Tmat matX2Y1 = pomozno_sestevanje(mat4, mat4, 
                                          //X2
                                          c1, cP, 
                                          bP, b2, 
                                          //Y1
                                          cP, c2, 
                                          b1, bP);
        
        
        Tmat matA1 = vrni_obmocje_matrike(mat1,
                                          //A1
                                          a1, aP, 
                                          b1, bP);
                                         
        Tmat matX1mX2 = pomozno_odstevanje(mat4, mat4, 
                                          //X1
                                          c1, cP, 
                                          b1, bP, 
                                          //X2
                                          c1, cP, 
                                          bP, b2);
        
        Tmat matA2A1 = pomozno_sestevanje(mat1, mat1, 
                                          //A2
                                          a1, aP, 
                                          bP, b2, 
                                          //A1
                                          a1, aP, 
                                          b1, bP);
                                          
        Tmat matX2 = vrni_obmocje_matrike(mat4,
                                          //X2
                                          c1, cP, 
                                          bP, b2);
        
        //prikaz2(mat2);
        //prikaz2(matX2);
        
        Tmat matB2 = vrni_obmocje_matrike(mat1,
                                          //B2
                                          aP, a2, 
                                          bP, b2);
                                          
        Tmat matY2mY1 = pomozno_odstevanje(mat4, mat4, 
                                          //Y2
                                          cP, c2, 
                                          bP, b2, 
                                          //Y1
                                          cP, c2, 
                                          b1, bP);
        
        Tmat matB1b2 = pomozno_sestevanje(mat1, mat1, 
                                          //B1
                                          aP, a2, 
                                          b1, bP, 
                                          //B2
                                          aP, a2, 
                                          bP, b2);
                                          
        Tmat matY1 = vrni_obmocje_matrike(mat4,
                                          //Y1
                                          cP, c2, 
                                          b1, bP);
                                          
        
        //std::function<Tmat(Tmat,Tmat)> lam_tra_mno = transponirano_mnozenje_pom;
        
        std::function<Tmat(Tmat &,Tmat &)> lam_tra_mno = gl_rekurzivno_transponirano_mno;
        
        Tmat matM1 = lam_tra_mno(matA1B1, matX1Y1);
        Tmat matM2 = lam_tra_mno(matA2B2, matX2Y2);
        Tmat matM3 = lam_tra_mno(matA1mB2, matX2Y1);
        Tmat matM4 = lam_tra_mno(matA1, matX1mX2);
        Tmat matM5 = lam_tra_mno(matA2A1, matX2);
        Tmat matM6 = lam_tra_mno(matB2, matY2mY1);
        Tmat matM7 = lam_tra_mno(matB1b2, matY1);
        
        /*
        prikaz2(matA1);
        prikaz2(matX1mX2);
        
        prikaz2(matA2A1);
        prikaz2(matX2);
        
        prikaz2(matM4);
        prikaz2(matM5);
        */
        
        pristej_rezultatu(matM4, mat3,
                          //A1*
                          a1, aP, 
                          c1, cP);
                          
        //prikaz2(mat3);
                          
        pristej_rezultatu(matM5, mat3,
                          //A1*
                          a1, aP, 
                          c1, cP);
                          
        //prikaz2(mat3);                  
                          
        pristej_rezultatu(matM2, mat3,
                          //A2*
                          a1, aP, 
                          cP, c2);
                          
        odstej_rezultatu(matM6, mat3,
                          //A2*
                          a1, aP, 
                          cP, c2);
                          
        pristej_rezultatu(matM3, mat3,
                          //A2*
                          a1, aP, 
                          cP, c2);
                          
        odstej_rezultatu(matM5, mat3,
                          //A2*
                          a1, aP, 
                          cP, c2);
                          
                          
                          
        pristej_rezultatu(matM1, mat3,
                          //B1*
                          aP, a2,
                          c1, cP);
        
        odstej_rezultatu(matM4, mat3,
                          //B1*
                          aP, a2,
                          c1, cP);
        
        odstej_rezultatu(matM3, mat3,
                          //B1*
                          aP, a2,
                          c1, cP);
        
        odstej_rezultatu(matM7, mat3,
                          //B1*
                          aP, a2,
                          c1, cP);
                          
                          
                          
        pristej_rezultatu(matM6, mat3,
                          //B2*
                          aP, a2,
                          cP, c2);
                          
        pristej_rezultatu(matM7, mat3,
                          //B2*
                          aP, a2,
                          cP, c2);
    }
}

Tmat gl_podkubicen_algoritem_tr(Tmat &mat1, Tmat &mat4){
    int a = mat1.size();
    int b = mat1[0].size();
    int c = mat4.size();
    int a1 = 0; 
    int b1 = 0;
    int c1 = 0;
    
    std::vector<double> nicelni(c, 0.0);
    Tmat mat3(a, nicelni);
    
    podkubicen_pomozna(mat1, mat4, mat3, a1, a,  b1, b, c1, c);
    
    return mat3;
}

Tmat podkubicen_algoritem_tr(Tmat &mat1, Tmat &mat2){
    Tmat mat4 = transponiraj(mat2);
    return gl_podkubicen_algoritem_tr(mat1, mat4);
}


Tmat gl_podkubicen_algoritem_tr2(Tmat &, Tmat &);

void podkubicen_pomozna2(Tmat &mat1, Tmat &mat4, Tmat &mat3,
                        int a1, int a2, 
                        int b1, int b2,
                        int c1, int c2){
    

    int aD = a2-a1;
    int bD = b2-b1;
    int cD = c2-c1;
    int aP = a1+aD/2;
    int bP = b1+bD/2;
    int cP = c1+cD/2;
    int minDabc = std::min({aD, bD, cD});
    
    if(minDabc<400){
        rek_tra_mno_pomozna(mat1, mat4, mat3, a1, a2,  b1, b2, c1, c2);
    }
    else{
        Tmat matA1B1 = pomozno_sestevanje(mat1, mat1, 
                                          //A1
                                          a1, aP, 
                                          b1, bP, 
                                          //B1
                                          aP, a2, 
                                          b1, bP);
                                          
        Tmat matX1Y1 = pomozno_sestevanje(mat4, mat4, 
                                          //X1
                                          c1, cP, 
                                          b1, bP, 
                                          //Y1
                                          cP, c2, 
                                          b1, bP);
        
        Tmat matA2B2 = pomozno_sestevanje(mat1, mat1, 
                                          //A2
                                          a1, aP, 
                                          bP, b2, 
                                          //B2
                                          aP, a2, 
                                          bP, b2);
        
        Tmat matX2Y2 = pomozno_sestevanje(mat4, mat4, 
                                          //X2
                                          c1, cP, 
                                          bP, b2, 
                                          //Y2
                                          cP, c2, 
                                          bP, b2);
        
        
        Tmat matA1mB2 = pomozno_odstevanje(mat1, mat1, 
                                          //A1
                                          a1, aP, 
                                          b1, bP, 
                                          //B2
                                          aP, a2, 
                                          bP, b2);
        
        Tmat matX2Y1 = pomozno_sestevanje(mat4, mat4, 
                                          //X2
                                          c1, cP, 
                                          bP, b2, 
                                          //Y1
                                          cP, c2, 
                                          b1, bP);
        
        
        Tmat matA1 = vrni_obmocje_matrike(mat1,
                                          //A1
                                          a1, aP, 
                                          b1, bP);
                                         
        Tmat matX1mX2 = pomozno_odstevanje(mat4, mat4, 
                                          //X1
                                          c1, cP, 
                                          b1, bP, 
                                          //X2
                                          c1, cP, 
                                          bP, b2);
        
        Tmat matA2A1 = pomozno_sestevanje(mat1, mat1, 
                                          //A2
                                          a1, aP, 
                                          bP, b2, 
                                          //A1
                                          a1, aP, 
                                          b1, bP);
                                          
        Tmat matX2 = vrni_obmocje_matrike(mat4,
                                          //X2
                                          c1, cP, 
                                          bP, b2);
        
        //prikaz2(mat2);
        //prikaz2(matX2);
        
        Tmat matB2 = vrni_obmocje_matrike(mat1,
                                          //B2
                                          aP, a2, 
                                          bP, b2);
                                          
        Tmat matY2mY1 = pomozno_odstevanje(mat4, mat4, 
                                          //Y2
                                          cP, c2, 
                                          bP, b2, 
                                          //Y1
                                          cP, c2, 
                                          b1, bP);
        
        Tmat matB1b2 = pomozno_sestevanje(mat1, mat1, 
                                          //B1
                                          aP, a2, 
                                          b1, bP, 
                                          //B2
                                          aP, a2, 
                                          bP, b2);
                                          
        Tmat matY1 = vrni_obmocje_matrike(mat4,
                                          //Y1
                                          cP, c2, 
                                          b1, bP);
                                          
        
        //std::function<Tmat(Tmat,Tmat)> lam_tra_mno = transponirano_mnozenje_pom;
        
        std::function<Tmat(Tmat &,Tmat &)> lam_tra_mno = gl_podkubicen_algoritem_tr2;
        
        Tmat matM1 = lam_tra_mno(matA1B1, matX1Y1);
        Tmat matM2 = lam_tra_mno(matA2B2, matX2Y2);
        Tmat matM3 = lam_tra_mno(matA1mB2, matX2Y1);
        Tmat matM4 = lam_tra_mno(matA1, matX1mX2);
        Tmat matM5 = lam_tra_mno(matA2A1, matX2);
        Tmat matM6 = lam_tra_mno(matB2, matY2mY1);
        Tmat matM7 = lam_tra_mno(matB1b2, matY1);
        
        /*
        prikaz2(matA1);
        prikaz2(matX1mX2);
        
        prikaz2(matA2A1);
        prikaz2(matX2);
        
        prikaz2(matM4);
        prikaz2(matM5);
        */
        
        pristej_rezultatu(matM4, mat3,
                          //A1*
                          a1, aP, 
                          c1, cP);
                          
        //prikaz2(mat3);
                          
        pristej_rezultatu(matM5, mat3,
                          //A1*
                          a1, aP, 
                          c1, cP);
                          
        //prikaz2(mat3);                  
                          
        pristej_rezultatu(matM2, mat3,
                          //A2*
                          a1, aP, 
                          cP, c2);
                          
        odstej_rezultatu(matM6, mat3,
                          //A2*
                          a1, aP, 
                          cP, c2);
                          
        pristej_rezultatu(matM3, mat3,
                          //A2*
                          a1, aP, 
                          cP, c2);
                          
        odstej_rezultatu(matM5, mat3,
                          //A2*
                          a1, aP, 
                          cP, c2);
                          
                          
                          
        pristej_rezultatu(matM1, mat3,
                          //B1*
                          aP, a2,
                          c1, cP);
        
        odstej_rezultatu(matM4, mat3,
                          //B1*
                          aP, a2,
                          c1, cP);
        
        odstej_rezultatu(matM3, mat3,
                          //B1*
                          aP, a2,
                          c1, cP);
        
        odstej_rezultatu(matM7, mat3,
                          //B1*
                          aP, a2,
                          c1, cP);
                          
                          
                          
        pristej_rezultatu(matM6, mat3,
                          //B2*
                          aP, a2,
                          cP, c2);
                          
        pristej_rezultatu(matM7, mat3,
                          //B2*
                          aP, a2,
                          cP, c2);
    }
}

Tmat gl_podkubicen_algoritem_tr2(Tmat &mat1, Tmat &mat4){
    int a = mat1.size();
    int b = mat1[0].size();
    int c = mat4.size();
    int a1 = 0; 
    int b1 = 0;
    int c1 = 0;
    
    std::vector<double> nicelni(c, 0.0);
    Tmat mat3(a, nicelni);
    
    podkubicen_pomozna(mat1, mat4, mat3, a1, a,  b1, b, c1, c);
    
    return mat3;
}

Tmat podkubicen_algoritem_tr2(Tmat &mat1, Tmat &mat2){
    Tmat mat4 = transponiraj(mat2);
    return gl_podkubicen_algoritem_tr(mat1, mat4);
}
